// --- Tab Navigation Logic ---
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        document.querySelectorAll('.tab-content').forEach(tc => tc.style.display = 'none');
        document.getElementById('tab-' + this.dataset.tab).style.display = 'block';
    });
});
// Show first tab by default
if (document.querySelector('.tab-btn')) {
    document.querySelector('.tab-btn').click();
}

// --- Message Box Helper ---
function showMessage(msg, type = 'info') {
    const box = document.getElementById('message-box');
    box.textContent = msg;
    box.style.display = 'block';
    box.style.background = type === 'error' ? '#ffe0e0' : (type === 'success' ? '#e0ffe0' : '#e0e7ff');
    box.style.color = type === 'error' ? '#a00' : '#222';
    setTimeout(() => { box.style.display = 'none'; }, 4000);
}

// --- Helper Functions ---
// These functions use fetch() to make API calls to the Flask backend.
// The DOM is updated directly with the results, so there is NO page reload (AJAX style).
// --- Search and Sorting State ---
let customerData = [], productData = [], subscriptionData = [];
let customerSort = {col: 'id', dir: 1}, productSort = {col: 'id', dir: 1}, subscriptionSort = {col: 'id', dir: 1};

function renderTable(data, tableId, columns, searchValue, sort) {
    let filtered = data.filter(row =>
        columns.some(col => String(row[col]).toLowerCase().includes(searchValue.toLowerCase()))
    );
    filtered.sort((a, b) => {
        if (a[sort.col] < b[sort.col]) return -1 * sort.dir;
        if (a[sort.col] > b[sort.col]) return 1 * sort.dir;
        return 0;
    });
    // Update sort indicators
    document.querySelectorAll(`#${tableId} th.sortable`).forEach(th => {
        th.classList.remove('sorted');
        th.innerHTML = th.textContent.replace(/\s*[▲▼]$/, '');
        if (th.dataset.col === sort.col) {
            th.classList.add('sorted');
            th.innerHTML = th.textContent + (sort.dir === 1 ? ' ▲' : ' ▼');
        }
    });
    const tbody = document.querySelector(`#${tableId} tbody`);
    tbody.innerHTML = '';
    filtered.forEach(row => {
        let tr = document.createElement('tr');
        if (tableId === 'customers-table') {
            tr.innerHTML = `
                <td>${row.id}</td>
                <td>${row.name}</td>
                <td>${row.email}</td>
                <td>${row.phone}</td>
                <td>${row.membership_status}</td>
                <td>
                    <button onclick="editCustomer(${row.id}, '${row.name}', '${row.email}', '${row.phone}', '${row.membership_status}')">Edit</button>
                    <button onclick="deleteCustomer(${row.id})">Delete</button>
                </td>
            `;
        } else if (tableId === 'products-table') {
            tr.innerHTML = `
                <td>${row.id}</td>
                <td>${row.name}</td>
                <td>${row.type}</td>
                <td>${row.price}</td>
                <td>${row.stock}</td>
                <td>
                    <button onclick="editProduct(${row.id}, '${row.name}', '${row.type}', ${row.price}, ${row.stock})">Edit</button>
                    <button onclick="deleteProduct(${row.id})">Delete</button>
                </td>
            `;
        } else if (tableId === 'subscriptions-table') {
            tr.innerHTML = `
                <td>${row.id}</td>
                <td>${row.customer_id}</td>
                <td>${row.type}</td>
                <td>${row.start_date}</td>
                <td>${row.end_date}</td>
                <td>
                    <button onclick="editSubscription(${row.id}, ${row.customer_id}, '${row.type}', '${row.start_date}', '${row.end_date}')">Edit</button>
                    <button onclick="deleteSubscription(${row.id})">Delete</button>
                </td>
            `;
        }
        tbody.appendChild(tr);
    });
}

function fetchAndRenderCustomers() {
    fetch('http://127.0.0.1:5000/api/customers')
        .then(res => res.json())
        .then(data => {
            customerData = data;
            const searchValue = document.getElementById('search-customers').value || '';
            renderTable(customerData, 'customers-table', ['id','name','email','phone','membership_status'], searchValue, customerSort);
        })
        .catch(err => showMessage('Failed to fetch customers: ' + err, 'error'));
}
function fetchAndRenderProducts() {
    fetch('http://127.0.0.1:5000/api/products')
        .then(res => res.json())
        .then(data => {
            productData = data;
            const searchValue = document.getElementById('search-products').value || '';
            renderTable(productData, 'products-table', ['id','name','type','price','stock'], searchValue, productSort);
        })
        .catch(err => showMessage('Failed to fetch products: ' + err, 'error'));
}
function fetchAndRenderSubscriptions() {
    fetch('http://127.0.0.1:5000/api/subscriptions')
        .then(res => res.json())
        .then(data => {
            subscriptionData = data;
            const searchValue = document.getElementById('search-subscriptions').value || '';
            renderTable(subscriptionData, 'subscriptions-table', ['id','customer_id','type','start_date','end_date'], searchValue, subscriptionSort);
        })
        .catch(err => showMessage('Failed to fetch subscriptions: ' + err, 'error'));
}

function fetchAndRenderStats() {
    fetch('http://127.0.0.1:5000/api/stats')
        .then(res => res.json())
        .then(stats => {
            document.getElementById('stat-total-customers').textContent = stats.total_customers;
            document.getElementById('stat-total-products').textContent = stats.total_products;
            document.getElementById('stat-total-products-in-stock').textContent = stats.total_products_in_stock;
            document.getElementById('stat-total-subscriptions').textContent = stats.total_subscriptions;
            document.getElementById('stat-active-subscriptions').textContent = stats.active_subscriptions;
        })
        .catch(err => showMessage('Failed to fetch stats: ' + err, 'error'));
}
// Update stats when Reports tab is shown
const tabBtns = document.querySelectorAll('.tab-btn');
tabBtns.forEach(btn => {
    btn.addEventListener('click', function() {
        if (this.dataset.tab === 'reports') fetchAndRenderStats();
    });
});
// Also update stats after any CRUD operation
function updateAllStats() { fetchAndRenderStats(); }

document.getElementById('search-customers').addEventListener('input', () => renderTable(customerData, 'customers-table', ['id','name','email','phone','membership_status'], document.getElementById('search-customers').value, customerSort));
document.getElementById('search-products').addEventListener('input', () => renderTable(productData, 'products-table', ['id','name','type','price','stock'], document.getElementById('search-products').value, productSort));
document.getElementById('search-subscriptions').addEventListener('input', () => renderTable(subscriptionData, 'subscriptions-table', ['id','customer_id','type','start_date','end_date'], document.getElementById('search-subscriptions').value, subscriptionSort));

document.querySelectorAll('#customers-table th.sortable').forEach(th => {
    th.addEventListener('click', function() {
        const col = this.dataset.col;
        customerSort.dir = customerSort.col === col ? -customerSort.dir : 1;
        customerSort.col = col;
        renderTable(customerData, 'customers-table', ['id','name','email','phone','membership_status'], document.getElementById('search-customers').value, customerSort);
    });
});
document.querySelectorAll('#products-table th.sortable').forEach(th => {
    th.addEventListener('click', function() {
        const col = this.dataset.col;
        productSort.dir = productSort.col === col ? -productSort.dir : 1;
        productSort.col = col;
        renderTable(productData, 'products-table', ['id','name','type','price','stock'], document.getElementById('search-products').value, productSort);
    });
});
document.querySelectorAll('#subscriptions-table th.sortable').forEach(th => {
    th.addEventListener('click', function() {
        const col = this.dataset.col;
        subscriptionSort.dir = subscriptionSort.col === col ? -subscriptionSort.dir : 1;
        subscriptionSort.col = col;
        renderTable(subscriptionData, 'subscriptions-table', ['id','customer_id','type','start_date','end_date'], document.getElementById('search-subscriptions').value, subscriptionSort);
    });
});

// --- CRUD for Customers ---
// --- Validation Helpers ---
function validateCustomerForm() {
    const name = document.getElementById('customer-name').value.trim();
    const email = document.getElementById('customer-email').value.trim();
    const phone = document.getElementById('customer-phone').value.trim();
    const emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
    if (!name) return 'Name is required.';
    if (!email) return 'Email is required.';
    if (!emailPattern.test(email)) return 'Invalid email format.';
    if (!phone) return 'Phone is required.';
    if (!/^\d+$/.test(phone)) return 'Phone must be numeric.';
    return null;
}
function validateProductForm() {
    const name = document.getElementById('product-name').value.trim();
    const type = document.getElementById('product-type').value;
    const price = document.getElementById('product-price').value;
    const stock = document.getElementById('product-stock').value;
    if (!name) return 'Name is required.';
    if (!type) return 'Type is required.';
    if (!price || isNaN(price) || Number(price) <= 0) return 'Price must be a positive number.';
    if (stock === '' || isNaN(stock) || Number(stock) < 0) return 'Stock must be 0 or greater.';
    return null;
}
function validateSubscriptionForm() {
    const customerId = document.getElementById('subscription-customer-id').value;
    const type = document.getElementById('subscription-type').value;
    const start = document.getElementById('subscription-start').value;
    const end = document.getElementById('subscription-end').value;
    if (!customerId || isNaN(customerId) || Number(customerId) <= 0) return 'Customer ID must be a positive number.';
    if (!type) return 'Type is required.';
    if (!start) return 'Start date is required.';
    if (!end) return 'End date is required.';
    if (start > end) return 'End date must be after start date.';
    return null;
}
document.getElementById('customer-form').onsubmit = function(e) {
    e.preventDefault();
    const err = validateCustomerForm();
    if (err) { showMessage(err, 'error'); return; }
    const id = document.getElementById('customer-id').value;
    const name = document.getElementById('customer-name').value;
    const email = document.getElementById('customer-email').value;
    const phone = document.getElementById('customer-phone').value;
    const membership = document.getElementById('customer-membership').value;
    const data = { name, email, phone, membership_status: membership };
    if (id) {
        fetch(`http://127.0.0.1:5000/api/customers/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => {
            if (!res.ok) throw new Error('Update failed: ' + res.status);
            showMessage('Customer updated!', 'success');
            this.reset();
            fetchAndRenderCustomers();
            updateAllStats();
        })
        .catch(err => showMessage('Error updating customer: ' + err, 'error'));
    } else {
        fetch('http://127.0.0.1:5000/api/customers', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => {
            if (!res.ok) throw new Error('Add failed: ' + res.status);
            showMessage('Customer added!', 'success');
            this.reset();
            fetchAndRenderCustomers();
            updateAllStats();
        })
        .catch(err => showMessage('Error adding customer: ' + err, 'error'));
    }
};

document.getElementById('customer-cancel').onclick = function() {
    document.getElementById('customer-form').reset();
    document.getElementById('customer-id').value = '';
};

window.editCustomer = function(id, name, email, phone, membership) {
    document.getElementById('customer-id').value = id;
    document.getElementById('customer-name').value = name;
    document.getElementById('customer-email').value = email;
    document.getElementById('customer-phone').value = phone;
    document.getElementById('customer-membership').value = membership;
};

window.deleteCustomer = function(id) {
    if (confirm('Delete this customer?')) {
        fetch(`http://127.0.0.1:5000/api/customers/${id}`, { method: 'DELETE' })
            .then(res => {
                if (!res.ok) throw new Error('Delete failed: ' + res.status);
                showMessage('Customer deleted!', 'success');
                fetchAndRenderCustomers();
                updateAllStats();
            })
            .catch(err => showMessage('Error deleting customer: ' + err, 'error'));
    }
};

// --- CRUD for Products ---
document.getElementById('product-form').onsubmit = function(e) {
    e.preventDefault();
    const err = validateProductForm();
    if (err) { showMessage(err, 'error'); return; }
    const id = document.getElementById('product-id').value;
    const name = document.getElementById('product-name').value;
    const type = document.getElementById('product-type').value;
    const price = parseFloat(document.getElementById('product-price').value);
    const stock = parseInt(document.getElementById('product-stock').value);
    const data = { name, type, price, stock };
    if (id) {
        fetch(`http://127.0.0.1:5000/api/products/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => {
            if (!res.ok) throw new Error('Update failed: ' + res.status);
            showMessage('Product updated!', 'success');
            this.reset();
            fetchAndRenderProducts();
            updateAllStats();
        })
        .catch(err => showMessage('Error updating product: ' + err, 'error'));
    } else {
        fetch('http://127.0.0.1:5000/api/products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => {
            if (!res.ok) throw new Error('Add failed: ' + res.status);
            showMessage('Product added!', 'success');
            this.reset();
            fetchAndRenderProducts();
            updateAllStats();
        })
        .catch(err => showMessage('Error adding product: ' + err, 'error'));
    }
};

document.getElementById('product-cancel').onclick = function() {
    document.getElementById('product-form').reset();
    document.getElementById('product-id').value = '';
};

window.editProduct = function(id, name, type, price, stock) {
    document.getElementById('product-id').value = id;
    document.getElementById('product-name').value = name;
    document.getElementById('product-type').value = type;
    document.getElementById('product-price').value = price;
    document.getElementById('product-stock').value = stock;
};

window.deleteProduct = function(id) {
    if (confirm('Delete this product?')) {
        fetch(`http://127.0.0.1:5000/api/products/${id}`, { method: 'DELETE' })
            .then(res => {
                if (!res.ok) throw new Error('Delete failed: ' + res.status);
                showMessage('Product deleted!', 'success');
                fetchAndRenderProducts();
                updateAllStats();
            })
            .catch(err => showMessage('Error deleting product: ' + err, 'error'));
    }
};

// --- CRUD for Subscriptions ---
document.getElementById('subscription-form').onsubmit = function(e) {
    e.preventDefault();
    const err = validateSubscriptionForm();
    if (err) { showMessage(err, 'error'); return; }
    const id = document.getElementById('subscription-id').value;
    const customer_id = parseInt(document.getElementById('subscription-customer-id').value);
    const type = document.getElementById('subscription-type').value;
    const start_date = document.getElementById('subscription-start').value;
    const end_date = document.getElementById('subscription-end').value;
    const data = { customer_id, type, start_date, end_date };
    if (id) {
        fetch(`http://127.0.0.1:5000/api/subscriptions/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => {
            if (!res.ok) throw new Error('Update failed: ' + res.status);
            showMessage('Subscription updated!', 'success');
            this.reset();
            fetchAndRenderSubscriptions();
            updateAllStats();
        })
        .catch(err => showMessage('Error updating subscription: ' + err, 'error'));
    } else {
        fetch('http://127.0.0.1:5000/api/subscriptions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => {
            if (!res.ok) throw new Error('Add failed: ' + res.status);
            showMessage('Subscription added!', 'success');
            this.reset();
            fetchAndRenderSubscriptions();
            updateAllStats();
        })
        .catch(err => showMessage('Error adding subscription: ' + err, 'error'));
    }
};

document.getElementById('subscription-cancel').onclick = function() {
    document.getElementById('subscription-form').reset();
    document.getElementById('subscription-id').value = '';
};

window.editSubscription = function(id, customer_id, type, start, end) {
    document.getElementById('subscription-id').value = id;
    document.getElementById('subscription-customer-id').value = customer_id;
    document.getElementById('subscription-type').value = type;
    document.getElementById('subscription-start').value = start;
    document.getElementById('subscription-end').value = end;
};

window.deleteSubscription = function(id) {
    if (confirm('Delete this subscription?')) {
        fetch(`http://127.0.0.1:5000/api/subscriptions/${id}`, { method: 'DELETE' })
            .then(res => {
                if (!res.ok) throw new Error('Delete failed: ' + res.status);
                showMessage('Subscription deleted!', 'success');
                fetchAndRenderSubscriptions();
                updateAllStats();
            })
            .catch(err => showMessage('Error deleting subscription: ' + err, 'error'));
    }
};

// --- Initial Data Load ---
fetchAndRenderCustomers();
fetchAndRenderProducts();
fetchAndRenderSubscriptions();
updateAllStats(); 