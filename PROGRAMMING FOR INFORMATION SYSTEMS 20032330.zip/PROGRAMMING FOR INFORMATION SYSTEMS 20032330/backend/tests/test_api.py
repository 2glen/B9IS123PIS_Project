import pytest
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__) + '/..'))
from app import app
import json

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_customers_crud(client):
    # Create
    resp = client.post('/api/customers', json={
        'name': 'Test User', 'email': 'testuser@example.com', 'phone': '1234567890', 'membership_status': 'Member'
    })
    assert resp.status_code == 201, f"Create customer failed: {resp.get_json()}"
    print('Customer created:', resp.get_json())
    # Read
    resp = client.get('/api/customers')
    data = resp.get_json()
    assert any(c['email'] == 'testuser@example.com' for c in data), "Customer not found after creation"
    # Update
    cust_id = next(c['id'] for c in data if c['email'] == 'testuser@example.com')
    resp = client.put(f'/api/customers/{cust_id}', json={
        'name': 'Test User2', 'email': 'testuser2@example.com', 'phone': '9876543210', 'membership_status': 'VIP'
    })
    assert resp.status_code == 200, f"Update customer failed: {resp.get_json()}"
    # Delete
    resp = client.delete(f'/api/customers/{cust_id}')
    assert resp.status_code == 200, f"Delete customer failed: {resp.get_json()}"

def test_products_crud(client):
    resp = client.post('/api/products', json={
        'name': 'Test Product', 'type': 'Ticket', 'price': 10.5, 'stock': 5
    })
    assert resp.status_code == 201, f"Create product failed: {resp.get_json()}"
    print('Product created:', resp.get_json())
    resp = client.get('/api/products')
    data = resp.get_json()
    assert any(p['name'] == 'Test Product' for p in data), "Product not found after creation"
    prod_id = next(p['id'] for p in data if p['name'] == 'Test Product')
    resp = client.put(f'/api/products/{prod_id}', json={
        'name': 'Test Product2', 'type': 'Merchandise', 'price': 20, 'stock': 10
    })
    assert resp.status_code == 200, f"Update product failed: {resp.get_json()}"
    resp = client.delete(f'/api/products/{prod_id}')
    assert resp.status_code == 200, f"Delete product failed: {resp.get_json()}"

def test_subscriptions_crud(client):
    # Need a customer first
    cust_resp = client.post('/api/customers', json={
        'name': 'Sub User', 'email': 'subuser@example.com', 'phone': '1112223333', 'membership_status': 'Member'
    })
    cust_id = client.get('/api/customers').get_json()[-1]['id']
    resp = client.post('/api/subscriptions', json={
        'customer_id': cust_id, 'type': 'Annual', 'start_date': '2025-01-01', 'end_date': '2025-12-31'
    })
    assert resp.status_code == 201, f"Create subscription failed: {resp.get_json()}"
    print('Subscription created:', resp.get_json())
    resp = client.get('/api/subscriptions')
    data = resp.get_json()
    assert any(s['customer_id'] == cust_id for s in data), "Subscription not found after creation"
    sub_id = next(s['id'] for s in data if s['customer_id'] == cust_id)
    resp = client.put(f'/api/subscriptions/{sub_id}', json={
        'customer_id': cust_id, 'type': 'Monthly', 'start_date': '2025-01-01', 'end_date': '2025-06-30'
    })
    assert resp.status_code == 200, f"Update subscription failed: {resp.get_json()}"
    resp = client.delete(f'/api/subscriptions/{sub_id}')
    assert resp.status_code == 200, f"Delete subscription failed: {resp.get_json()}"
    # Clean up customer
    client.delete(f'/api/customers/{cust_id}')

def test_stats(client):
    resp = client.get('/api/stats')
    assert resp.status_code == 200, "Stats endpoint failed"
    stats = resp.get_json()
    assert 'total_customers' in stats, "Missing total_customers in stats"
    assert 'total_products' in stats, "Missing total_products in stats"
    assert 'total_subscriptions' in stats, "Missing total_subscriptions in stats"
    assert 'active_subscriptions' in stats, "Missing active_subscriptions in stats"
    print('Stats:', stats)

def test_integration_add_customer(client):
    resp = client.post('/api/customers', json={
        'name': 'Integration User', 'email': 'integration@example.com', 'phone': '5556667777', 'membership_status': 'VIP'
    })
    assert resp.status_code == 201, f"Integration add customer failed: {resp.get_json()}"
    resp = client.get('/api/customers')
    data = resp.get_json()
    assert any(c['email'] == 'integration@example.com' for c in data), "Integration customer not found"
    # Clean up
    cust_id = next(c['id'] for c in data if c['email'] == 'integration@example.com')
    client.delete(f'/api/customers/{cust_id}')

def test_customer_validation(client):
    resp = client.post('/api/customers', json={
        'name': '', 'email': 'bademail', 'phone': 'abc', 'membership_status': 'None'
    })
    assert resp.status_code == 400, "Should fail on invalid customer data"
    print('Customer validation error:', resp.get_json())

def test_product_validation(client):
    resp = client.post('/api/products', json={
        'name': '', 'type': '', 'price': -5, 'stock': -1
    })
    assert resp.status_code == 400, "Should fail on invalid product data"
    print('Product validation error:', resp.get_json())

def test_subscription_validation(client):
    resp = client.post('/api/subscriptions', json={
        'customer_id': 0, 'type': '', 'start_date': '', 'end_date': ''
    })
    assert resp.status_code == 400, "Should fail on invalid subscription data"
    print('Subscription validation error:', resp.get_json())

def test_delete_nonexistent_customer(client):
    resp = client.delete('/api/customers/999999')
    assert resp.status_code == 200, "Deleting nonexistent customer should still return 200"
    print('Delete nonexistent customer:', resp.get_json())

def test_get_empty_products(client):
    # Delete all products
    resp = client.get('/api/products')
    for p in resp.get_json():
        client.delete(f"/api/products/{p['id']}")
    resp = client.get('/api/products')
    assert resp.get_json() == [], "Products table should be empty after deleting all"
    print('Products after delete all:', resp.get_json()) 