from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import re
from datetime import date

app = Flask(__name__)
CORS(app)
DATABASE = 'museum.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def validate_customer(data):
    if not data.get('name'): return 'Name is required.'
    if not data.get('email'): return 'Email is required.'
    if not re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', data['email']): return 'Invalid email format.'
    if not data.get('phone'): return 'Phone is required.'
    if not str(data['phone']).isdigit(): return 'Phone must be numeric.'
    return None

def validate_product(data):
    if not data.get('name'): return 'Name is required.'
    if not data.get('type'): return 'Type is required.'
    try:
        price = float(data.get('price', 0))
        stock = int(data.get('stock', 0))
    except:
        return 'Price and stock must be numbers.'
    if price <= 0: return 'Price must be positive.'
    if stock < 0: return 'Stock must be 0 or greater.'
    return None

def validate_subscription(data):
    try:
        customer_id = int(data.get('customer_id', 0))
    except:
        return 'Customer ID must be a positive number.'
    if customer_id <= 0: return 'Customer ID must be a positive number.'
    if not data.get('type'): return 'Type is required.'
    if not data.get('start_date'): return 'Start date is required.'
    if not data.get('end_date'): return 'End date is required.'
    if data['start_date'] > data['end_date']: return 'End date must be after start date.'
    return None

# --- Customers Endpoints ---
@app.route('/api/customers', methods=['GET'])
def get_customers():
    conn = get_db()
    customers = conn.execute('SELECT * FROM customers').fetchall()
    conn.close()
    return jsonify([dict(row) for row in customers])

@app.route('/api/customers', methods=['POST'])
def add_customer():
    data = request.get_json()
    err = validate_customer(data)
    if err:
        return jsonify({'error': err}), 400
    conn = get_db()
    cur = conn.cursor()
    cur.execute('INSERT INTO customers (name, email, phone, membership_status) VALUES (?, ?, ?, ?)',
                (data['name'], data['email'], data['phone'], data.get('membership_status', 'None')))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Customer added'}), 201

@app.route('/api/customers/<int:id>', methods=['PUT'])
def update_customer(id):
    data = request.get_json()
    err = validate_customer(data)
    if err:
        return jsonify({'error': err}), 400
    conn = get_db()
    conn.execute('UPDATE customers SET name=?, email=?, phone=?, membership_status=? WHERE id=?',
                 (data['name'], data['email'], data['phone'], data.get('membership_status', 'None'), id))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Customer updated'})

@app.route('/api/customers/<int:id>', methods=['DELETE'])
def delete_customer(id):
    conn = get_db()
    conn.execute('DELETE FROM customers WHERE id=?', (id,))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Customer deleted'})

# --- Products Endpoints ---
@app.route('/api/products', methods=['GET'])
def get_products():
    conn = get_db()
    products = conn.execute('SELECT * FROM products').fetchall()
    conn.close()
    return jsonify([dict(row) for row in products])

@app.route('/api/products', methods=['POST'])
def add_product():
    data = request.get_json()
    err = validate_product(data)
    if err:
        return jsonify({'error': err}), 400
    conn = get_db()
    cur = conn.cursor()
    cur.execute('INSERT INTO products (name, type, price, stock) VALUES (?, ?, ?, ?)',
                (data['name'], data['type'], data['price'], data['stock']))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Product added'}), 201

@app.route('/api/products/<int:id>', methods=['PUT'])
def update_product(id):
    data = request.get_json()
    err = validate_product(data)
    if err:
        return jsonify({'error': err}), 400
    conn = get_db()
    conn.execute('UPDATE products SET name=?, type=?, price=?, stock=? WHERE id=?',
                 (data['name'], data['type'], data['price'], data['stock'], id))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Product updated'})

@app.route('/api/products/<int:id>', methods=['DELETE'])
def delete_product(id):
    conn = get_db()
    conn.execute('DELETE FROM products WHERE id=?', (id,))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Product deleted'})

# --- Subscriptions Endpoints ---
@app.route('/api/subscriptions', methods=['GET'])
def get_subscriptions():
    conn = get_db()
    subs = conn.execute('SELECT * FROM subscriptions').fetchall()
    conn.close()
    return jsonify([dict(row) for row in subs])

@app.route('/api/subscriptions', methods=['POST'])
def add_subscription():
    data = request.get_json()
    err = validate_subscription(data)
    if err:
        return jsonify({'error': err}), 400
    conn = get_db()
    cur = conn.cursor()
    cur.execute('INSERT INTO subscriptions (customer_id, type, start_date, end_date) VALUES (?, ?, ?, ?)',
                (data['customer_id'], data['type'], data['start_date'], data['end_date']))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Subscription added'}), 201

@app.route('/api/subscriptions/<int:id>', methods=['PUT'])
def update_subscription(id):
    data = request.get_json()
    err = validate_subscription(data)
    if err:
        return jsonify({'error': err}), 400
    conn = get_db()
    conn.execute('UPDATE subscriptions SET customer_id=?, type=?, start_date=?, end_date=? WHERE id=?',
                 (data['customer_id'], data['type'], data['start_date'], data['end_date'], id))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Subscription updated'})

@app.route('/api/subscriptions/<int:id>', methods=['DELETE'])
def delete_subscription(id):
    conn = get_db()
    conn.execute('DELETE FROM subscriptions WHERE id=?', (id,))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Subscription deleted'})

@app.route('/api/stats', methods=['GET'])
def get_stats():
    conn = get_db()
    total_customers = conn.execute('SELECT COUNT(*) FROM customers').fetchone()[0]
    total_products = conn.execute('SELECT COUNT(*) FROM products').fetchone()[0]
    total_products_in_stock = conn.execute('SELECT SUM(stock) FROM products').fetchone()[0] or 0
    total_subscriptions = conn.execute('SELECT COUNT(*) FROM subscriptions').fetchone()[0]
    today = date.today().isoformat()
    active_subscriptions = conn.execute('SELECT COUNT(*) FROM subscriptions WHERE end_date >= ?', (today,)).fetchone()[0]
    conn.close()
    return jsonify({
        'total_customers': total_customers,
        'total_products': total_products,
        'total_products_in_stock': total_products_in_stock,
        'total_subscriptions': total_subscriptions,
        'active_subscriptions': active_subscriptions
    })

if __name__ == '__main__':
    app.run(debug=True) 